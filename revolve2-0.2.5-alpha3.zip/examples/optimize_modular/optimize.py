import logging
from random import Random

import multineat
from genotype import random as random_genotype
#from optimizer import Optimizer
from optimizer_rugged import Optimizer

from revolve2.core.database import open_async_database_sqlite
from revolve2.core.optimization import ProcessIdGen

# Path to module maximum count
#virtualEnvLatest/revolve2-0.2.4-alpha3/genotypes/cppnwin/revolve2/genotypes/cppnwin/modular_robot/body_genotype_v1.py


async def main(amount_of_runs) -> None:
    # number of initial mutations for body and brain CPPNWIN networks
    # NUM_INITIAL_MUTATIONS = 10

    # SIMULATION_TIME = 10
    # SAMPLING_FREQUENCY = 5
    # CONTROL_FREQUENCY = 5
    #
    # POPULATION_SIZE = 10
    # OFFSPRING_SIZE = 10
    # NUM_GENERATIONS = 3

    NUM_INITIAL_MUTATIONS = 50

    SIMULATION_TIME = 30
    SAMPLING_FREQUENCY = 5
    CONTROL_FREQUENCY = 10
    POPULATION_SIZE = 100
    OFFSPRING_SIZE = 100
    NUM_GENERATIONS = 150

    logging.basicConfig(
        level=logging.INFO,
        format="[%(asctime)s] [%(levelname)s] [%(module)s] %(message)s",
    )

    logging.info(f"Starting optimization")

    # database
    database = open_async_database_sqlite("./database")

    # process id generator
    process_id_gen = ProcessIdGen()

    # multineat innovation databases
    innov_db_body = multineat.InnovationDatabase()
    innov_db_brain = multineat.InnovationDatabase()

    for experiment in range(amount_of_runs):


        print("I am in run {}".format(experiment))
        # random number generator
        rng = Random()
        rng.seed(experiment)



        initial_population = [
            random_genotype(innov_db_body, innov_db_brain, rng, NUM_INITIAL_MUTATIONS)
            for _ in range(POPULATION_SIZE)
        ]

        process_id = process_id_gen.gen()
        maybe_optimizer = await Optimizer.from_database(
            database=database,
            process_id=process_id,
            innov_db_body=innov_db_body,
            innov_db_brain=innov_db_brain,
            rng=rng,
            process_id_gen=process_id_gen,
        )
        if maybe_optimizer is not None:
            optimizer = maybe_optimizer
        else:
            optimizer = await Optimizer.new(
                database=database,
                process_id=process_id,
                initial_population=initial_population,
                rng=rng,
                process_id_gen=process_id_gen,
                innov_db_body=innov_db_body,
                innov_db_brain=innov_db_brain,
                simulation_time=SIMULATION_TIME,
                sampling_frequency=SAMPLING_FREQUENCY,
                control_frequency=CONTROL_FREQUENCY,
                num_generations=NUM_GENERATIONS,
                offspring_size=OFFSPRING_SIZE,
                run_number=experiment,

            )

        logging.info("Starting optimization process..")

        await optimizer.run()

        logging.info(f"Finished optimizing.")

if __name__ == "__main__":
    import asyncio
    AMOUNT_OF_RUNS = 5
    if True:
        import shutil
        import os
            # remove this went you want to keewp data in database file
         #dir_path = '/home/gidi/Desktop/database'
        dir_path = '/home/ibilgin/Desktop/database'

        try:
            shutil.rmtree(dir_path)
            print("I deleted database Gidi")

        except OSError as e:
            print("Error: %s : %s" % (dir_path, e.strerror))

        files = 'virtualEnvLatest/revolve2-0.2.5-alpha3/morphologies'
        try:
            shutil.rmtree(files)
            os.mkdir(files)

        except OSError as e:
            print("Error: %s : %s" % (files, e.strerror))
            os.mkdir(files)

        for experiment in range(AMOUNT_OF_RUNS):
            os.mkdir(files+f'/run_{experiment}')






    asyncio.run(main(AMOUNT_OF_RUNS))
