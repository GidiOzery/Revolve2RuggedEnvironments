==============
CPPNWIN
==============
CPPN with innovation numbers
CPPN + innovation numbers, crossover, mutation taken from NEAT.
Name made up by ci-group
TODO