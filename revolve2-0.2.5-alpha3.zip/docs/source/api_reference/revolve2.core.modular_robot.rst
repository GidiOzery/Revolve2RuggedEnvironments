revolve2.core.modular\_robot package
====================================

Subpackages
-----------

.. toctree::
   :maxdepth: 1

   brains <revolve2.core.modular_robot.brains>

Module contents
---------------

.. automodule:: revolve2.core.modular_robot
   :members:
   :undoc-members:
   :show-inheritance:
