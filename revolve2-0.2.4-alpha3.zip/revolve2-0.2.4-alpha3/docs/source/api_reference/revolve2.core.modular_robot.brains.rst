revolve2.core.modular\_robot.brains package
===========================================

Module contents
---------------

.. automodule:: revolve2.core.modular_robot.brains
   :members:
   :undoc-members:
   :show-inheritance:
