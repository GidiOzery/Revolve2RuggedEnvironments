class SerializeError(Exception):
    pass
